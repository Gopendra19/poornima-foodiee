/* main.js - fixed cart renderer + toast + menu/product loading */
const API_BASE = "http://localhost:5000";

let cart = JSON.parse(localStorage.getItem("cart") || "[]");
cart = cart.map(i => ({ qty: i.qty || 1, ...i }));

document.addEventListener("DOMContentLoaded", () => {
  tryInitHero();
  updateCartCount();
  loadProducts();
  loadMenuPage();
  setupCartUI();
  setupReviewUI();
  wireCheckoutPage();
});

/* --------------- HERO --------------- */
function tryInitHero(){
  const slidesContainer = document.querySelector('.hero-slides');
  const heroSlides = document.querySelectorAll('.hero-slide');
  const heroNext = document.getElementById('hero-next');
  const heroPrev = document.getElementById('hero-prev');
  let heroIndex = 0;
  const slideCount = heroSlides.length || 0;
  function updateHero() {
    if(!slidesContainer) return;
    slidesContainer.style.transform = `translateX(-${heroIndex * 100}%)`;
  }
  if(slideCount > 0){
    heroNext?.addEventListener('click', () => { heroIndex = (heroIndex + 1) % slideCount; updateHero(); });
    heroPrev?.addEventListener('click', () => { heroIndex = (heroIndex - 1 + slideCount) % slideCount; updateHero(); });
    setTimeout(updateHero, 300);
    setInterval(() => { heroIndex = (heroIndex + 1) % slideCount; updateHero(); }, 6000);
  }
}

/* --------------- LOAD PRODUCTS --------------- */
function loadProducts() {
  const container = document.getElementById("popularItems");
  if (!container) return;
  fetch(`${API_BASE}/products`).then(r => r.json()).then(products => {
    container.innerHTML = products.slice(0,5).map(p => `
      <div class="product-card">
        <img src="${p.image||''}" alt="${p.name}">
        <h4>${p.name}</h4>
        <p>₹${p.price}</p>
        <button class="btn primary">Add to Cart</button>
      </div>
    `).join("");
  }).catch(err => {
    console.error("Error loading products:", err);
    container.innerHTML = "<p style='color:#777'>Unable to load products</p>";
  });
}

function loadMenuPage() {
  const container = document.getElementById("menu-container");
  if (!container) return;
  fetch(`${API_BASE}/products`).then(r => r.json()).then(products => {
    container.innerHTML = products.map(p => `
      <div class="product-card menu-card">
        <img src="${p.image||''}" alt="${p.name}">
        <h3>${p.name}</h3>
        <p>₹${p.price}</p>
        <button class="btn primary">Add to Cart</button>
      </div>
    `).join("");
  }).catch(err => {
    console.error("Error loading menu:", err);
    container.innerHTML = "<p style='color:#777'>Unable to load menu</p>";
  });
}

/* --------------- TOAST --------------- */
function showToast(msg = "Added to cart") {
  let t = document.getElementById("app-toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "app-toast";
    t.style.position = "fixed";
    t.style.right = "20px";
    t.style.bottom = "20px";
    t.style.background = "#333";
    t.style.color = "#fff";
    t.style.padding = "10px 14px";
    t.style.borderRadius = "8px";
    t.style.zIndex = 999999;
    t.style.opacity = 0;
    t.style.transition = "0.25s";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity = 1;
  clearTimeout(t._hideTimer);
  t._hideTimer = setTimeout(() => { t.style.opacity = 0; }, 1600);
}

/* --------------- ADD TO CART (delegated) --------------- */
document.addEventListener("click", (e) => {
  const target = e.target;
  if (!target || target.tagName !== "BUTTON") return;
  if (!/add\s*to\s*cart/i.test(target.textContent)) return;

  const card = target.closest(".product-card, .menu-card");
  if (!card) return;

  const nameEl = card.querySelector("h3, h4");
  const priceEl = card.querySelector("p");
  const imgEl = card.querySelector("img");

  const name = nameEl ? nameEl.innerText.trim() : "Item";
  const price = priceEl ? Number(priceEl.innerText.replace(/[^\d.]/g, "")) || 0 : 0;
  const image = imgEl ? imgEl.src : "";

  const existing = cart.find(i => i.name === name);
  if (existing) existing.qty += 1;
  else cart.push({ id: Date.now(), name, price, image, qty: 1 });

  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  showToast("✔ Item added to cart");
});

/* --------------- CART COUNT --------------- */
function updateCartCount() {
  const el = document.getElementById("cart-count");
  if (!el) return;
  const total = cart.reduce((s, i) => s + (i.qty || 0), 0);
  el.textContent = total;
}

/* --------------- CART RENDER (full) --------------- */
function renderCartPanel() {
  const list = document.getElementById("cart-list");
  const totalEl = document.getElementById("total-price");
  if (!list || !totalEl) return;
  if (cart.length === 0) {
    list.innerHTML = "<p style='padding:12px;color:#777'>No items in cart</p>";
    totalEl.textContent = 0;
    return;
  }
  let total = 0;
  list.innerHTML = "";
  cart.forEach((it, idx) => {
    total += (Number(it.price) || 0) * (it.qty || 1);
    const row = document.createElement("div");
    row.className = "cart-item-row";
    row.style.display = "flex";
    row.style.gap = "12px";
    row.style.alignItems = "center";
    row.style.marginBottom = "12px";
    row.innerHTML = `
      <img src="${it.image||''}" width="60" height="46" style="object-fit:cover;border-radius:8px">
      <div style="flex:1">
        <strong style="display:block">${it.name}</strong>
        <div style="color:#777">₹${it.price} × ${it.qty}</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <button class="decrease btn" data-idx="${idx}">-</button>
        <button class="increase btn" data-idx="${idx}">+</button>
        <button class="removeItemBtn btn" data-idx="${idx}">Remove</button>
      </div>
    `;
    list.appendChild(row);
  });
  totalEl.textContent = total;

  // attach controls
  document.querySelectorAll(".removeItemBtn").forEach(b => b.addEventListener("click", (e) => {
    const i = Number(e.currentTarget.dataset.idx);
    cart.splice(i, 1); saveAndRerender();
  }));
  document.querySelectorAll(".increase").forEach(b => b.addEventListener("click", (e) => {
    const i = Number(e.currentTarget.dataset.idx);
    cart[i].qty = (cart[i].qty || 1) + 1; saveAndRerender();
  }));
  document.querySelectorAll(".decrease").forEach(b => b.addEventListener("click", (e) => {
    const i = Number(e.currentTarget.dataset.idx);
    if (cart[i].qty > 1) cart[i].qty -= 1;
    else cart.splice(i,1);
    saveAndRerender();
  }));

  function saveAndRerender(){
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
    renderCartPanel();
  }
}

/* --------------- CART UI --------------- */
function setupCartUI() {
  const openCart = document.getElementById("open-cart");
  const closeCart = document.getElementById("close-cart");
  const cartPanel = document.getElementById("cart-panel");
  const overlay = document.getElementById("overlay");

  openCart?.addEventListener("click", () => {
    cartPanel?.classList.add("open");
    overlay?.classList.add("open");
    renderCartPanel();
  });

  closeCart?.addEventListener("click", () => {
    cartPanel?.classList.remove("open");
    overlay?.classList.remove("open");
  });

  overlay?.addEventListener("click", () => {
    cartPanel?.classList.remove("open");
    overlay?.classList.remove("open");
  });

  document.getElementById("clear-cart")?.addEventListener("click", () => {
    cart = [];
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
    renderCartPanel();
  });

  document.getElementById("go-checkout")?.addEventListener("click", () => {
    window.location.href = "checkout.html";
  });
}

/* --------------- CHECKOUT --------------- */
function wireCheckoutPage(){
  const orderListEl = document.getElementById("orderList");
  const totalAmountEl = document.getElementById("totalAmount");
  const checkoutForm = document.getElementById("checkoutForm");
  if (!orderListEl || !totalAmountEl || !checkoutForm) return;

  orderListEl.innerHTML = "";
  let total = 0;
  cart.forEach(i => {
    const li = document.createElement("li");
    li.innerText = `${i.name} — ₹${i.price} × ${i.qty}`;
    orderListEl.appendChild(li);
    total += (Number(i.price) || 0) * (i.qty || 1);
  });
  totalAmountEl.textContent = total;

  checkoutForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = checkoutForm.querySelector('input[type="text"]')?.value || "";
    const mobile = checkoutForm.querySelector('input[type="tel"]')?.value || "";
    const address = checkoutForm.querySelectorAll('input[type="text"]')[1]?.value || "";
    const payment = checkoutForm.querySelector('select')?.value || "Cash On Delivery";
    if (!name || !mobile || !address) {
      alert("Please fill all fields");
      return;
    }
    const order = {
      id: Date.now(),
      name, mobile, address, payment,
      items: cart.map(i => ({ name: i.name, price: i.price, qty: i.qty })),
      total, time: Date.now()
    };
    try {
      const res = await fetch(`${API_BASE}/orders`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      });
      if (!res.ok) throw new Error("Network response not ok");
      localStorage.setItem("poornima_last_order", JSON.stringify(order));
      cart = []; localStorage.setItem("cart", JSON.stringify(cart));
      updateCartCount();
      window.location.href = "receipt.html";
    } catch (err) {
      console.warn("Could not POST order to backend, saving locally:", err);
      const localOrders = JSON.parse(localStorage.getItem("poornima_orders") || "[]");
      localOrders.push(order);
      localStorage.setItem("poornima_orders", JSON.stringify(localOrders));
      localStorage.setItem("poornima_last_order", JSON.stringify(order));
      cart = []; localStorage.setItem("cart", JSON.stringify(cart));
      updateCartCount();
      window.location.href = "receipt.html";
    }
  });
}

/* --------------- REVIEWS --------------- */
function setupReviewUI(){
  const reviewForm = document.getElementById("reviewForm");
  if (!reviewForm) return;
  let reviews = JSON.parse(localStorage.getItem("poornima_reviews") || "[]");
  const reviewsContainer = document.getElementById("reviewsContainer");
  function showReviews() {
    if (!reviewsContainer) return;
    reviewsContainer.innerHTML = "";
    reviews.forEach(r => {
      const div = document.createElement("div");
      div.className = "review-card";
      div.innerHTML = `
        ${r.photo ? `<img src="${r.photo}" class="review-img">` : ""}
        <h3>${r.name}</h3>
        <p class="stars">${"★".repeat(Number(r.rating || 0))}</p>
        <p class="review-text">${r.msg}</p>
      `;
      reviewsContainer.appendChild(div);
    });
  }
  showReviews();
  reviewForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const rating = document.getElementById("rating").value;
    const msg = document.getElementById("message").value;
    const picFile = document.getElementById("profilePic").files[0];
    function finish(photoData){
      const newReview = { name, rating, msg, photo: photoData || "" };
      fetch(`${API_BASE}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newReview)
      }).catch(err => {
        const arr = JSON.parse(localStorage.getItem("poornima_reviews") || "[]");
        arr.push(newReview);
        localStorage.setItem("poornima_reviews", JSON.stringify(arr));
      });
      reviews.push(newReview);
      localStorage.setItem("poornima_reviews", JSON.stringify(reviews));
      showReviews();
      reviewForm.reset();
      alert("✔ Review Submitted Successfully!");
    }
    if (picFile) {
      const reader = new FileReader();
      reader.onload = () => finish(reader.result);
      reader.readAsDataURL(picFile);
    } else finish("");
  });
}

/* expose for debug */
window.updateCartCount = updateCartCount;
window.renderCartPanel = renderCartPanel;
window.__cart = cart;
