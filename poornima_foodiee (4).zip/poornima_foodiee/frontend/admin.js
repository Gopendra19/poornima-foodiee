/* admin.js - complete admin panel script (orders + products) */
const API_BASE = "http://localhost:5000";

/* ---------------- ORDERS ---------------- */
async function loadOrders() {
  const tbody = document.getElementById("ordersBody");
  if (!tbody) return;
  tbody.innerHTML = "<tr><td colspan='7'>Loading...</td></tr>";
  try {
    const res = await fetch(`${API_BASE}/orders`);
    if (!res.ok) throw new Error("Fetch failed");
    const orders = await res.json();
    if (!orders.length) {
      tbody.innerHTML = "<tr><td colspan='7' style='text-align:center;color:#777;'>No Orders Found</td></tr>";
      return;
    }
    tbody.innerHTML = "";
    orders.slice().reverse().forEach(order => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${order.id}</td>
        <td>${order.name || ''}</td>
        <td>₹${order.total || 0}</td>
        <td>${order.payment || ''}</td>
        <td>${order.address || '—'}</td>
        <td>${new Date(order.time).toLocaleString()}</td>
        <td>
          <button class="del-order-btn" data-id="${order.id}">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
    // bind delete buttons
    document.querySelectorAll(".del-order-btn").forEach(b => b.addEventListener("click", (e) => {
      const id = e.currentTarget.dataset.id;
      deleteOrder(id);
    }));
  } catch (err) {
    tbody.innerHTML = "<tr><td colspan='7' style='color:red;'>Error loading orders</td></tr>";
    console.error(err);
  }
}

async function deleteOrder(id) {
  if (!confirm("Delete this order?")) return;
  try {
    const res = await fetch(`${API_BASE}/orders/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Delete failed");
    alert("Order deleted");
    loadOrders();
  } catch (err) {
    alert("Backend error. Check server!");
    console.error(err);
  }
}

/* ---------------- PRODUCTS (ADMIN CRUD) ---------------- */
async function loadAdminProducts() {
  const container = document.getElementById("product-list");
  if (!container) return;
  container.innerHTML = "<p>Loading...</p>";
  try {
    const res = await fetch(`${API_BASE}/products`);
    const products = await res.json();
    if (!products.length) {
      container.innerHTML = "<p style='color:#777'>No products</p>";
      return;
    }
    container.innerHTML = "";
    products.slice().reverse().forEach(p => {
      const div = document.createElement("div");
      div.className = "admin-prod-row";
      div.style.padding = "8px";
      div.style.borderBottom = "1px solid #eee";
      div.innerHTML = `
        <div style="display:flex;gap:10px;align-items:center">
          <img src="${p.image||''}" width="60" style="object-fit:cover;border-radius:6px">
          <div style="flex:1">
            <strong>${p.name}</strong><br>
            <small>₹${p.price} • ${p.category||''}</small>
          </div>
          <div style="display:flex;gap:6px">
            <button class="edit-prod btn" data-id="${p.id}">Edit</button>
            <button class="del-prod btn" data-id="${p.id}">Delete</button>
          </div>
        </div>
      `;
      container.appendChild(div);
    });

    document.querySelectorAll(".edit-prod").forEach(b => b.addEventListener("click", (e) => {
      const id = e.currentTarget.dataset.id;
      populateProductForEdit(id);
    }));
    document.querySelectorAll(".del-prod").forEach(b => b.addEventListener("click", (e) => {
      const id = e.currentTarget.dataset.id;
      deleteProduct(id);
    }));
  } catch (err) {
    container.innerHTML = "<p style='color:red'>Error loading products</p>";
    console.error(err);
  }
}

async function populateProductForEdit(id) {
  try {
    const res = await fetch(`${API_BASE}/products`);
    const products = await res.json();
    const p = products.find(x => String(x.id) === String(id));
    if (!p) return alert("Product not found");
    document.getElementById("p_id").value = p.id;
    document.getElementById("pname").value = p.name || "";
    document.getElementById("pprice").value = p.price || "";
    document.getElementById("pcategory").value = p.category || "";
    document.getElementById("pdesc").value = p.description || "";
    if (p.image) {
      const img = document.getElementById("pimg_preview");
      img.src = p.image;
      img.style.display = "block";
    }
  } catch (err) {
    console.error(err);
  }
}

async function saveProductHandler() {
  const id = document.getElementById("p_id").value;
  const name = document.getElementById("pname").value.trim();
  const price = Number(document.getElementById("pprice").value || 0);
  const category = document.getElementById("pcategory").value.trim();
  const desc = document.getElementById("pdesc").value.trim();
  // image (we will read base64 if file selected)
  const fileInput = document.getElementById("pfile");
  let imageData = "";
  if (fileInput && fileInput.files && fileInput.files[0]) {
    const f = fileInput.files[0];
    imageData = await readFileAsDataURL(f);
  } else {
    const preview = document.getElementById("pimg_preview");
    if (preview && preview.src) imageData = preview.src;
  }

  const payload = { name, price, category, description: desc, image: imageData };

  try {
    if (id) {
      // update
      const res = await fetch(`${API_BASE}/products/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Update failed");
      alert("Product updated");
    } else {
      // create
      const res = await fetch(`${API_BASE}/products`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Create failed");
      alert("Product created");
    }
    clearProductForm();
    loadAdminProducts();
  } catch (err) {
    alert("Error saving product");
    console.error(err);
  }
}

function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

function clearProductForm() {
  document.getElementById("p_id").value = "";
  document.getElementById("pname").value = "";
  document.getElementById("pprice").value = "";
  document.getElementById("pcategory").value = "";
  document.getElementById("pdesc").value = "";
  document.getElementById("pfile").value = "";
  const img = document.getElementById("pimg_preview");
  if (img) { img.style.display = "none"; img.src = ""; }
}

async function deleteProduct(id) {
  if (!confirm("Delete this product?")) return;
  try {
    const res = await fetch(`${API_BASE}/products/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Delete failed");
    alert("Product deleted");
    loadAdminProducts();
  } catch (err) {
    alert("Backend error deleting product");
    console.error(err);
  }
}

/* ---------------- ADMIN LOGIN ---------------- */
async function loginAdmin() {
  const pass = document.getElementById("adminPass")?.value;
  try {
    const res = await fetch(`${API_BASE}/admin/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: pass })
    });
    if (!res.ok) throw new Error("Login failed");
    const data = await res.json();
    localStorage.setItem("adminToken", data.token);
    window.location.href = "admin.html";
  } catch (err) {
    alert("Wrong password or server offline");
  }
}

/* ---------------- DOM ---------------- */
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("ordersBody")) loadOrders();
  if (document.getElementById("product-list")) loadAdminProducts();

  const logoutBtn = document.getElementById("logout");
  if (logoutBtn) logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("adminToken");
    window.location.href = "admin-login.html";
  });

  const saveBtn = document.getElementById("saveProduct");
  if (saveBtn) saveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    saveProductHandler();
  });

  // preview image when selected
  const fileInput = document.getElementById("pfile");
  if (fileInput) fileInput.addEventListener("change", () => {
    const f = fileInput.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      const img = document.getElementById("pimg_preview");
      img.src = r.result;
      img.style.display = "block";
    };
    r.readAsDataURL(f);
  });

  const clearBtn = document.getElementById("clear-form");
  if (clearBtn) clearBtn.addEventListener("click", (e) => {
    clearProductForm();
  });
});
